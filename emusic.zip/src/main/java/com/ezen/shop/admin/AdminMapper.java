package com.ezen.shop.admin;

public interface AdminMapper {

	AdminDto admin_ok(String ad_userid);
}
