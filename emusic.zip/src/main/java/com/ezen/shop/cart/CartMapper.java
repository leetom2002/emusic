package com.ezen.shop.cart;

import java.util.List;
import java.util.Map;

public interface CartMapper {
	
	void cart_add(CartVO vo);
	
	List<Map<String, Object>> getCartDetailsByUserId(String mbspId);
	
	int getCartTotalPriceByUserId(String mbspId);
	
	void cart_empty(String mbspId);
}
