package com.ezen.shop.admin.order;

import java.util.List;
import java.util.Map;

import com.ezen.shop.common.utils.SearchCriteria;

public interface AdOrderMapper {

	List<Map<String, Object>> order_list(SearchCriteria cri);
	
	int getTotalCount (SearchCriteria cri);
}
