package com.ezen.shop.admin.order;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ezen.shop.common.utils.SearchCriteria;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AdOrderService {

	private final AdOrderMapper adOrderMapper;
	
	public List<Map<String, Object>> order_list(SearchCriteria cri) {
		return adOrderMapper.order_list(cri);
	}
	
	public int getTotalCount (SearchCriteria cri) {
		return adOrderMapper.getTotalCount(cri);
	}
}
