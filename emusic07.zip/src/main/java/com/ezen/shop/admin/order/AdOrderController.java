package com.ezen.shop.admin.order;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.shop.common.utils.PageMaker;
import com.ezen.shop.common.utils.SearchCriteria;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@RequestMapping("/admin/order/*")
@Controller
public class AdOrderController {

	
	private final AdOrderService adOrderService;
	
	// 주문목록
	@GetMapping("/order_list")
	public void order_list(SearchCriteria cri, Model model) throws Exception {
		
		
		log.info("cri: " + cri.getPageStart());
		
		List<Map<String, Object>> order_list = adOrderService.order_list(cri);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(adOrderService.getTotalCount(cri));
		
		model.addAttribute("order_list", order_list);
		model.addAttribute("pageMaker", pageMaker);
		
		
	}
}
