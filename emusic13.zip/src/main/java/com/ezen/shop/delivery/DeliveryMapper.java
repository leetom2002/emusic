package com.ezen.shop.delivery;

public interface DeliveryMapper {

	void delivery_insert(DeliveryVO deliveryVO);
}
