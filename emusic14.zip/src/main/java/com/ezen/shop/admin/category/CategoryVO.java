package com.ezen.shop.admin.category;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CategoryVO {

	private Integer cate_code;
	private Integer cate_prtcode;
	private String cate_name;
}
