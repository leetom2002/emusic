package com.ezen.shop.payment;

//@Mapper
public interface PaymentMapper {

	
	void payment_insert(PaymentVO vo);
}
