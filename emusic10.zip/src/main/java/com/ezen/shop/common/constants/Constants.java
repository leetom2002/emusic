package com.ezen.shop.common.constants;

public class Constants {

	// 전체소스에 영향을 미치는 상수선언.
	
	// 관리자의 상품목록 페이지별 개수설정.
	public static final int ADMIN_PRODUCT_LIST_COUNT = 2;
	// 관리자의 상품목록 페이지의 개수설정
	public static final int ADMIN_PRODUCT_LIST_PAGESIZE = 5;
}
